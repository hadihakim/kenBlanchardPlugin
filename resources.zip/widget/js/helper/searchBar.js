"use strict";

let mySearchingPeriod;
const { horizontal1_Skeleton, horizontal_Skeleton, verticalSeeAll_Skeleton } = skeleton();


