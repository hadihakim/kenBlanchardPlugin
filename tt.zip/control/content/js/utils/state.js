const state = {
    settings: {},
};