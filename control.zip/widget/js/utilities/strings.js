const Strings = {
	EXPLORE_BTN:"Explore All",
	SEE_ALL_TEXT:"See All",
	SEARCH_HOLDER:"Search",
	APPLY_SORT:"APPLY",
	APPLY_FILTER:"APPLY",
	SORT_TITLE:"Sorting",
	FILTER_TITLE:"Topics",
	START_CHAPTER:"Start chapter",
	START_COURSE:"Start Course",
	EMPTY_TITLE:"Nothing Found",
	EMPTY_DESCRIPTION:"Refine your search...",
}

