const state = {
    settings: {},
};